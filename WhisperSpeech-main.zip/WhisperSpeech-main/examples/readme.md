This folder contains examples of basic usage of the WhisperSpeech library.
